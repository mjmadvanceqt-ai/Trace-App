import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, Switch, TouchableOpacity, NativeModules, Alert } from 'react-native';

const { AppBlockerModule } = NativeModules;

export default function App() {
  const [isBlockingEnabled, setIsBlockingEnabled] = useState(false);

  useEffect(() => {
    checkPermission();
  }, []);

  const checkPermission = async () => {
    try {
      if (AppBlockerModule) {
        const hasPermission = await AppBlockerModule.checkAccessibilityPermission();
        if (!hasPermission && isBlockingEnabled) {
          Alert.alert(
            "Permission Required",
            "DayDial needs Accessibility permission to monitor and block distracting apps.",
            [
              { text: "Cancel", onPress: () => setIsBlockingEnabled(false) },
              { text: "Grant", onPress: () => AppBlockerModule.openAccessibilitySettings() }
            ]
          );
        }
      }
    } catch (error) {
      console.error("Permission check failed", error);
    }
  };

  const toggleBlocking = (value) => {
    setIsBlockingEnabled(value);
    if (AppBlockerModule) {
      if (value) {
        checkPermission();
        AppBlockerModule.startSignalingBlocker(true);
      } else {
        AppBlockerModule.startSignalingBlocker(false);
      }
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.headerTitle}>DayDial</Text>
      <Text style={styles.subtitle}>Time Block & Focus Manager</Text>
      
      <View style={styles.card}>
        <Text style={styles.cardText}>App Blocker Status</Text>
        <Switch
          trackColor={{ false: '#767577', true: '#3b82f6' }}
          thumbColor={isBlockingEnabled ? '#f5dd4b' : '#f4f3f4'}
          onValueChange={toggleBlocking}
          value={isBlockingEnabled}
        />
      </View>

      <TouchableOpacity style={styles.button} onPress={() => Alert.alert("Stats", "Tracking metrics coming soon!")}>
        <Text style={styles.buttonText}>View Usage Analytics</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#121212', alignItems: 'center', justifyContent: 'center', padding: 20 },
  headerTitle: { fontSize: 32, fontWeight: 'bold', color: '#fff', marginBottom: 5 },
  subtitle: { fontSize: 16, color: '#aaa', marginBottom: 40 },
  card: { flexDirection: 'row', backgroundColor: '#1e1e1e', padding: 20, borderRadius: 12, alignItems: 'center', width: '100%', justifyContent: 'space-between', marginBottom: 20 },
  cardText: { fontSize: 18, color: '#fff', fontWeight: '500' },
  button: { backgroundColor: '#3b82f6', paddingVertical: 15, paddingHorizontal: 30, borderRadius: 8, width: '100%', alignItems: 'center' },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: 'bold' }
});
