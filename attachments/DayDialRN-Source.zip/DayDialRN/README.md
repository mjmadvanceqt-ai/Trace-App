# DayDialRN

A rewritten application layout transitioning from Dart to React Native.

## Features
- Scalable JavaScript core configuration for UI dashboard layout.
- Decoupled native background processing bridge (`AppBlockerModule.kt`).
- Android operating-system hook module (`MyAccessibilityService.kt`).

## GitHub Deployment Setup
1. Unzip this package inside your staging directory.
2. Initialize repository or push straight to remote setup hooks.
