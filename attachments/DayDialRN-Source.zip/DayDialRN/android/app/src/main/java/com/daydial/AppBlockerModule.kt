package com.daydial

import android.content.Context
import android.content.Intent
import android.provider.Settings
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.bridge.Promise

class AppBlockerModule(reactContext: ReactApplicationContext) : ReactContextBaseJavaModule(reactContext) {

    override fun getName(): String {
        return "AppBlockerModule"
    }

    @ReactMethod
    fun openAccessibilitySettings() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        reactApplicationContext.startActivity(intent)
    }

    @ReactMethod
    fun checkAccessibilityPermission(promise: Promise) {
        val context: Context = reactApplicationContext
        val string = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        )
        val isEnabled = string?.contains(context.packageName) ?: false
        promise.resolve(isEnabled)
    }

    @ReactMethod
    fun startSignalingBlocker(enable: Boolean) {
        val sharedPref = reactApplicationContext.getSharedPreferences("DayDialPrefs", Context.MODE_PRIVATE)
        with (sharedPref.edit()) {
            putBoolean("is_blocking_active", enable)
            apply()
        }
    }
}
