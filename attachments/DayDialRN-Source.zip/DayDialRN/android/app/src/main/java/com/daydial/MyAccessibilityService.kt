package com.daydial

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class MyAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val packageName = event.packageName?.toString() ?: return
            
            // Check if blocking is toggled on via Javascript UI shared configuration
            val sharedPref = getSharedPreferences("DayDialPrefs", Context.MODE_PRIVATE)
            val isBlockingActive = sharedPref.getBoolean("is_blocking_active", false)

            if (isBlockingActive) {
                // Simplified demonstration matching original goal: detect targeted distracting apps
                if (packageName.contains("instagram") || packageName.contains("facebook") || packageName.contains("twitter")) {
                    // Redirect execution or provide user alert feedback safely
                    val launchIntent = packageManager.getLaunchIntentForPackage(this.packageName)
                    if (launchIntent != null) {
                        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(launchIntent)
                        Toast.makeText(this, "DayDial: This time block restricts social media apps!", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    override fun onInterrupt() {}
}
